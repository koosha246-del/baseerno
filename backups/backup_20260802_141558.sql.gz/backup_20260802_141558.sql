--
-- PostgreSQL database dump
--

\restrict qBfJMPCGfeiUVl2REY8TiKbT8meIdXAT1GVfeQGvKpwm7k3IWrnoTUOpwn5ecay

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: EnrollmentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EnrollmentStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'DROPPED'
);


ALTER TYPE public."EnrollmentStatus" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'STUDENT',
    'TEACHER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "actorId" text,
    action text NOT NULL,
    "targetType" text NOT NULL,
    "targetId" text,
    meta jsonb,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: Certificate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Certificate" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    "enrollmentId" text NOT NULL,
    "certificateNumber" text NOT NULL,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Certificate" OWNER TO postgres;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Course" (
    id text NOT NULL,
    title text NOT NULL,
    subtitle text NOT NULL,
    description text NOT NULL,
    "mentorId" text NOT NULL,
    price integer,
    "originalPrice" integer,
    level text DEFAULT 'مقدماتی'::text NOT NULL,
    category text NOT NULL,
    "durationHours" integer NOT NULL,
    lessons integer NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    glyph text NOT NULL,
    accent text NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Course" OWNER TO postgres;

--
-- Name: CourseSearch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseSearch" (
    id text NOT NULL,
    title text NOT NULL,
    subtitle text NOT NULL,
    "searchVector" tsvector
);


ALTER TABLE public."CourseSearch" OWNER TO postgres;

--
-- Name: EmailOutbox; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailOutbox" (
    id text NOT NULL,
    "to" text NOT NULL,
    subject text NOT NULL,
    html text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "lastError" text,
    "nextAttemptAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailOutbox" OWNER TO postgres;

--
-- Name: Enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Enrollment" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    status public."EnrollmentStatus" DEFAULT 'ACTIVE'::public."EnrollmentStatus" NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Enrollment" OWNER TO postgres;

--
-- Name: Grade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Grade" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    "enrollmentId" text NOT NULL,
    score double precision NOT NULL,
    feedback text,
    "gradedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "teacherId" text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Grade" OWNER TO postgres;

--
-- Name: Lesson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lesson" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'video'::text NOT NULL,
    "videoUrl" text,
    "durationMinutes" integer NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isFree" boolean DEFAULT false NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Lesson" OWNER TO postgres;

--
-- Name: LoadRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoadRun" (
    id text NOT NULL,
    "baseUrl" text NOT NULL,
    vus integer NOT NULL,
    "durationSeconds" integer NOT NULL,
    pass boolean NOT NULL,
    scenarios jsonb NOT NULL,
    "cacheHits" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoadRun" OWNER TO postgres;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    body text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Message" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    link text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    amount integer NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    method text NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "gatewayAuthority" text,
    "gatewayRefId" text
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'STUDENT'::public."Role" NOT NULL,
    avatar text,
    phone text,
    bio text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "twoFactorSecret" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "actorId", action, "targetType", "targetId", meta, ip, "createdAt") FROM stdin;
cmsacjyw60005m8v0b6af83vk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:27:44.358
cmsacldgm0006m8v0ocmoh0px	u_admin_1	auth.login	User	u_admin_1	\N	\N	2026-08-01 12:28:49.894
cmsacuih60007m8v0d8x4z3nu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:35:56.298
cmsacuipx0008m8v0jm03nq2x	u_teacher_1	auth.login	User	u_teacher_1	\N	\N	2026-08-01 12:35:56.613
cmsacuiyk0009m8v04tjzf28b	u_admin_1	auth.login	User	u_admin_1	\N	\N	2026-08-01 12:35:56.925
cmsacwp33000bm8v09aroopbt	cmsacwp14000am8v0w51dhs9w	auth.register	User	cmsacwp14000am8v0w51dhs9w	{"email": "tester1785587854@baseerno.ir"}	\N	2026-08-01 12:37:38.175
cmsacwpk1000em8v0smp7ztx7	u_student_1	payment.created	Course	c_leadership	{"amount": 1650000}	\N	2026-08-01 12:37:38.785
cmsacxc4e000gm8v0lmrnoq3p	u_student_1	payment.created	Course	c_leadership	{"amount": 1650000}	\N	2026-08-01 12:38:08.03
cmsad41lk000pm8v0hnihjyzw	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:43:20.984
cmsafqi7000000wv0zg30ouqk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 13:56:48.156
cmsafqi9700010wv015gvzr5u	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 13:56:48.235
cmsafut5700020wv0arinof8k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:00:08.971
cmsafutcd00030wv0h4kzif6k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:00:09.229
cmsafy3b200040wv0mplnv7uc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:02:42.11
cmsafz5cu00050wv0fzi8x6gq	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:31.422
cmsafz5cw00060wv01wa1mouc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:31.424
cmsafz5gk00070wv0knqzce2w	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:31.556
cmsafzbt400080wv01wsz7thl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:39.784
cmsafzbt400090wv06pff4lq0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:39.784
cmsafzbu3000a0wv02wns1cjr	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:03:39.819
cmsag07pj000b0wv0nr9junkj	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:21.127
cmsag07pk000c0wv026ur4veo	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:21.128
cmsag07ta000d0wv0wy5qjea3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:21.262
cmsag0d8a000e0wv05f9m05zi	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:28.282
cmsag0d8b000f0wv00q13ogjb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:28.283
cmsag0d8c000g0wv0fqrzulzl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:28.284
cmsag0zzm000h0wv0568ps19k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:57.778
cmsag0zzn000i0wv0tezeoriy	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:57.779
cmsag100l000j0wv04rho2lut	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:04:57.813
cmsag1z8z000k0wv0x1e4v0ac	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:43.475
cmsag20bz000l0wv04dzswvni	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:44.879
cmsag20c0000m0wv0bzpyvxkg	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:44.88
cmsag20c1000o0wv074n40jvt	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:44.881
cmsag20c3000p0wv03zxnhxca	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:44.883
cmsag20c1000n0wv0mnyeqkw5	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:44.881
cmsag20x5000q0wv05jlinfve	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:45.641
cmsag20x6000r0wv0ehwxxi5j	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:45.642
cmsag21ma000s0wv030a7u3f7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:46.546
cmsag21mb000t0wv09h7b9k4s	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:46.547
cmsag21ux000u0wv0rb9tr3yc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:46.857
cmsag22m9000w0wv0tq6552py	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:47.841
cmsag22m8000v0wv08d9o886l	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:47.84
cmsag22pz000x0wv09docq0fq	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:47.975
cmsag233y000y0wv0dbpwufhu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:48.478
cmsag2374000z0wv083o0shr5	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:48.592
cmsag247u00100wv03colq065	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:49.914
cmsag24ec00110wv0zuj9w5iy	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:50.148
cmsag24ed00120wv064f3jlsh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:50.149
cmsag24n000130wv0lqo1ugk8	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:50.46
cmsag250a00140wv08vu2fpvo	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:50.938
cmsag25bv00150wv0smmnnhch	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:51.355
cmsag25ok00160wv05bhqmxey	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:51.812
cmsag268z00170wv012witlz9	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:52.547
cmsag269000180wv04fxyrp6f	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:52.548
cmsag269100190wv00atffgmn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:52.549
cmsag26f5001a0wv0h4s9q1ca	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:52.769
cmsag26n4001b0wv01xpnvg2q	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:53.056
cmsag26vv001c0wv0f1rjhahn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:53.371
cmsag27hr001d0wv0o8toudr7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:54.159
cmsag27re001e0wv0tlm97sbw	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:54.506
cmsag286r001f0wv082eqq6t5	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:55.059
cmsag28f5001g0wv0w2sofwwf	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:55.361
cmsag28w5001h0wv0mf5x0ry7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:55.973
cmsag28xl001i0wv0dmzeonj0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:56.025
cmsag2961001j0wv0cp1pljap	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:56.329
cmsag29vy001k0wv0opkfs1e6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:57.262
cmsag29vy001l0wv04957v5el	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:57.262
cmsag29vz001m0wv04wwehvvy	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:57.263
cmsag2a9g001n0wv0rxtj234z	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:57.748
cmsag2abf001o0wv03fjnjpah	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:57.819
cmsag2aqf001p0wv0ns4b4swb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:58.359
cmsag2b2t001q0wv0x2sb6sgh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:05:58.805
cmsag2c9t001r0wv05jdcgfrn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:00.353
cmsag2cdh001s0wv0c6vk87a2	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:00.485
cmsag2cdi001t0wv0op1jd13i	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:00.486
cmsag2ctg001w0wv0fmj269p4	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:01.06
cmsag2d70001x0wv0rmm3ej8q	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:01.548
cmsag2dfo001y0wv0sn2eaykv	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:01.86
cmsag2cdi001u0wv02ok6d4nn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:00.486
cmsag2cle001v0wv0zknpb8le	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:00.77
cmsag2dsr001z0wv0m5th9qcc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:02.331
cmsag2du100200wv0wamt9ee7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:02.377
cmsag2ek600210wv076k1nrph	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:03.318
cmsag2g3u00220wv0r0ao1hfl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:05.322
cmsag36vu00230wv082ix7qaz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:06:40.026
cmsag3tt600240wv0bgtv9muc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:07:09.738
cmsag5tql00250wv0y7kvh2gp	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:42.957
cmsag5uto00260wv084ah16oa	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.364
cmsag5utq00270wv0xz6b8ovk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.366
cmsag5uts00280wv0z5bwnobx	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.368
cmsag5utt002a0wv0fmzbsqah	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.369
cmsag5utt00290wv0zfy7l7ca	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.369
cmsag5vb0002b0wv08tauv744	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.988
cmsag5vb1002c0wv0hq1ffyq8	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:44.989
cmsag5vp6002d0wv0f327a220	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:45.498
cmsag5vx3002e0wv0ck5wy5xh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:45.783
cmsag5wbb002f0wv0noutlaa9	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:46.295
cmsag5wm0002g0wv0pptewsa8	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:46.68
cmsag5wwh002h0wv0frrlblf0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:47.057
cmsag5xbp002i0wv0w32oyhgg	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:47.605
cmsag5xu9002j0wv0bysh7wvv	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:48.273
cmsag5yf0002k0wv01ty1fb8a	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:49.02
cmsag5yf1002l0wv05c8pzfyn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:49.021
cmsag5yf2002m0wv0c813yqw9	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:49.022
cmsag5yml002n0wv0dz709ac1	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:49.293
cmsag5yml002o0wv0mzj185la	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:49.293
cmsag5zjs002p0wv076mmv0rs	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:50.488
cmsag5zjs002q0wv06oia5zpu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:50.488
cmsag5zjt002r0wv0m7ymt2gi	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:50.489
cmsag60ga002s0wv0ntfsy96x	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:51.658
cmsag60gc002u0wv0lfzzf43p	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:51.66
cmsag60gb002t0wv0gfdbxze5	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:51.659
cmsag60gd002v0wv0pxoj0tzd	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:51.661
cmsag60kh002w0wv0egb62dsb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:51.809
cmsag60s1002x0wv0y4x9lbnx	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:52.081
cmsag61dp002y0wv0caol2c6n	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:52.861
cmsag62bn002z0wv0mgio2kse	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:54.083
cmsag62j500300wv0dtf382p6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:54.353
cmsag62uc00310wv0p57j9tix	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:54.756
cmsag62ym00320wv0r1nlxmcq	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:54.91
cmsag63ba00330wv04zgeb3be	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:55.366
cmsag63ih00340wv0vj6ahl8b	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:55.625
cmsag63ta00350wv0pf9eek6m	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:56.014
cmsag63tb00360wv0oejiorj1	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:56.015
cmsag640700370wv04n70nslb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:56.263
cmsag64lp00380wv0sy6edrcb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:57.037
cmsag64x500390wv0g8sd6c8e	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:57.449
cmsag65jd003a0wv0ied1pmj7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:58.249
cmsag66id003b0wv0eylv4ukn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.509
cmsag66ie003c0wv00aj3xb76	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.51
cmsag66ie003d0wv0xgdwldlz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.51
cmsag66ie003e0wv0p4fprq7k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.51
cmsag66jj003f0wv0gwtad2it	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.551
cmsag66ud003g0wv0h2nmahmv	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:08:59.941
cmsag6727003h0wv0h72egjlr	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:00.223
cmsag683q003i0wv0n1pb39i6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:01.574
cmsag68g3003j0wv0y6aqh275	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:02.019
cmsag68h4003k0wv0hng6f0h3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:02.056
cmsag68zk003l0wv0k5szwjqo	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:02.72
cmsag6axs003m0wv0hypn0ly9	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:05.248
cmsag6b6j003n0wv0luzsty39	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:09:05.563
cmsag8kai003o0wv0qeqz8vfk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:50.682
cmsag8lkz003t0wv0ewsbn0lx	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:52.355
cmsag8lko003p0wv0ag6w8hyk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:52.344
cmsag8lks003q0wv0vxbu36uz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:52.348
cmsag8lkt003r0wv05xli88c0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:52.349
cmsag8lku003s0wv0g85lj5e7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:52.35
cmsag8mbj003u0wv0y1pa01tz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:53.311
cmsag8mbk003v0wv0n4okwo0n	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:53.312
cmsag8mtb003w0wv0m3zwost4	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:53.951
cmsag8mz4003x0wv0vjysln97	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:54.16
cmsag8ns9003y0wv0aj9pc6aw	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:10:55.209
cmsaghav500420wv0rls1v6ai	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:38.369
cmsaghbv600430wv0jkraz2xt	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.666
cmsaghbv700440wv0obnkguno	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.667
cmsaghbvb00470wv0bhunuskf	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.671
cmsaghbva00460wv0outz4i8n	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.67
cmsaghbv900450wv0lmumy11w	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.669
cmsaghc4700480wv05im6xnm4	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:39.992
cmsaghcd500490wv06d8kzeal	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:40.313
cmsaghcr1004a0wv0iien5hef	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:40.813
cmsaghd64004b0wv0s94jgj69	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:41.356
cmsaghgpo004l0wv0cvuxdkf3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:45.948
cmsaghdgj004c0wv0lj03j9z7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:41.731
cmsaghdu1004d0wv0gdxhox70	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:42.217
cmsagheqt004h0wv049l1pocx	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:43.397
cmsaghfko004i0wv0s3q5k5n6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:44.472
cmsaghe5x004e0wv0f4ukuz76	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:42.645
cmsaghedf004f0wv03akf0yyl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:42.915
cmsagheqt004g0wv0ofv3cg6j	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:43.397
cmsaghglf004j0wv0vbrkijod	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:45.795
cmsaghgpn004k0wv0nburoln7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:45.947
cmsaghgpp004m0wv0g65uc7ub	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:45.949
cmsaghgxw004n0wv08rv58oum	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:46.244
cmsaghie3004o0wv0cca5iilz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:48.124
cmsaghiup004p0wv0u72ertir	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:48.721
cmsaghj1b004q0wv0x9a4dmsu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:48.959
cmsaghjtg004r0wv04rg0i5s3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:49.972
cmsaghkkv004s0wv0rj4f41ur	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:50.959
cmsaghkue004t0wv0ngs10o42	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:51.302
cmsaghmp9004u0wv0rrlreine	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:53.71
cmsaghn78004v0wv0akzvq2gf	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:54.356
cmsaghnsk004w0wv02074dns6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:55.124
cmsagho77004x0wv0py4acna4	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:55.651
cmsaghq03004y0wv0f99jz8ko	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:57.987
cmsaghqef004z0wv0v0sqzhee	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:17:58.503
cmsagizol00500wv0oyoraer3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:57.189
cmsagj0nw00510wv0hdrxbw1i	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.46
cmsagj0nx00520wv0jhdonnzu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.461
cmsagj0nx00530wv0akphocz9	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.461
cmsagj0ny00550wv0y6eu5i2h	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.462
cmsagj0ny00540wv0awq67jz0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.462
cmsagj0wu00560wv0dqzqx9f3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:58.782
cmsagj17a00570wv06rmcs8kf	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:59.159
cmsagj1io00580wv0d5afnye2	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:18:59.568
cmsagj1xq00590wv0e77wesax	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:00.11
cmsagj1xr005a0wv06ztjk4lo	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:00.111
cmsagj28e005b0wv0lygdshal	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:00.494
cmsagj2go005c0wv0o37ut53r	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:00.793
cmsagj2o9005d0wv0cfrefcud	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:01.065
cmsagj2y0005e0wv0ltb1x0bz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:01.416
cmsagj38u005f0wv03arnxct3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:01.806
cmsagj53v005g0wv0indbzd9x	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:04.219
cmsagj53v005h0wv0ai0013cr	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:04.219
cmsagj53w005i0wv02aatodwa	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:04.22
cmsagj5dq005j0wv0belyy97k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:04.574
cmsagj5ho005k0wv0v5fi8o1l	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:04.716
cmsagj5q5005l0wv0s85gpp1g	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:05.021
cmsagj73w005m0wv0dmi81pww	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:06.812
cmsagj7hm005n0wv0f65hkqpj	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:07.306
cmsagj7oc005o0wv0z3pfik5k	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:07.548
cmsagj7ur005p0wv0mw2tel1b	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:07.779
cmsagj89s005q0wv0wdlta4ex	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:08.32
cmsagj8m9005r0wv0unbjiwxq	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:08.769
cmsagjbks005s0wv0rk4vd78q	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:12.604
cmsagjbrb005t0wv0g3h67b2i	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:12.839
cmsagjbzm005u0wv0joygguyo	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:13.138
cmsagjc6h005v0wv0eopjqqff	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:13.385
cmsagjckg005w0wv0z75gteda	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:13.888
cmsagjcsg005x0wv07o6hrs8r	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:14.176
cmsagk69o005y0wv07qob8187	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:52.38
cmsagk77k00600wv0fcylbud7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.6
cmsagk77j005z0wv0in0m6w9l	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.599
cmsagk77l00610wv0jv8kcaai	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.601
cmsagk77l00620wv0gt4k3ews	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.601
cmsagk77m00630wv0v5eo8yxe	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.602
cmsagk7ga00640wv0slbmqgyh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:53.914
cmsagk7ol00650wv07vro51tl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:54.213
cmsagk80m00660wv07oq4bzff	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:54.646
cmsagk8cu00670wv0alvucl4p	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:55.086
cmsagk8e000680wv07c21ur2t	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:55.128
cmsagk8sn00690wv0gbmys66f	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:55.655
cmsagk9fl006a0wv06uotogl7	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:56.481
cmsagk9us006b0wv0kb7790c3	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:57.028
cmsagka18006c0wv0ar3yqmgk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:57.261
cmsagka7q006d0wv0swdv5hgs	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:57.494
cmsagkay0006e0wv0vxvhmrk6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:58.44
cmsagkbq3006f0wv00umnupc0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:59.451
cmsagkbq4006g0wv0b0m9m8zg	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:59.452
cmsagkbq5006i0wv0hiwqqeol	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:59.453
cmsagkbq4006h0wv074fjun3t	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:19:59.452
cmsagkcal006j0wv0ypgela90	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:00.189
cmsagkcxo006k0wv0mr7gv9nl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:01.02
cmsagkdpj006l0wv00vcveecl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:02.023
cmsagker6006m0wv06nayx4dz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:03.378
cmsagkf6q006n0wv02bmm0ht8	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:03.938
cmsagkfdk006o0wv0te5a5tqp	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:04.184
cmsagkfn0006p0wv0ebdgc6ul	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:04.524
cmsagkh9w006q0wv07l2m48rv	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:06.644
cmsagki5o006r0wv0uzhheylh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:07.788
cmsagkic2006s0wv0gmkron76	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:08.019
cmsagkk6q006t0wv0i36idi4g	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:10.418
cmsagkkji006u0wv03b2z6awe	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:10.878
cmsagklmr006v0wv02ojy5jkl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:12.291
cmsagl525006w0wv0eead5jwm	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:37.469
cmsagl525006x0wv09muaehkb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:37.469
cmsagl52t006y0wv03qcepr9e	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:20:37.493
cmsagm2h1006z0wv0omgm3zof	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:21:20.773
cmsagm2kk00700wv0manfi9et	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:21:20.9
cmsagoqfl00710wv0bp4ur8mh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:23:25.137
cmsagoqgb00720wv0vtddodqz	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:23:25.163
cmsagpxne00730wv0ty9my6hi	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:21.146
cmsagpyn400740wv0hgu3g17t	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.432
cmsagpyn500750wv0z61ngiz4	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.433
cmsagpyn600760wv0gop5m243	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.434
cmsagpyn700770wv068wo28g8	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.435
cmsagpyn700780wv06w0k02e6	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.435
cmsagpywu00790wv0av74ygot	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:22.782
cmsagpz68007a0wv05x1hoptp	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:23.12
cmsagpzir007b0wv0sbaam04x	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:23.571
cmsagpzq9007c0wv0y9wgfc4e	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:23.841
cmsagq08m007d0wv08x0d0oa2	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:24.502
cmsagq0me007e0wv0ewym0ta2	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:24.998
cmsagq0oa007f0wv0sn0b8qgy	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:25.066
cmsagq13a007g0wv05x7p991c	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:25.606
cmsagq1fm007i0wv0vcs7uw2e	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:26.05
cmsagq1fl007h0wv0bhbzv9hc	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:26.049
cmsagq2ll007j0wv0hndq5rrt	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:27.561
cmsagq2lm007k0wv0ihfmtopg	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:27.562
cmsagq3jk007l0wv0gwfz0vbh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:28.784
cmsagq3jl007m0wv0g7244ojv	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:28.785
cmsagq3ku007n0wv065mmspsf	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:28.83
cmsagq3x3007o0wv0j4r2l517	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:29.272
cmsagq44a007p0wv0o79pgpjp	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:29.53
cmsagq5v3007q0wv0506zn7kh	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:31.791
cmsagq634007r0wv0xi5l9n6x	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:32.08
cmsagq6ep007s0wv0z64ix7rb	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:32.497
cmsagq6ll007t0wv0f2uu0put	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:32.745
cmsagq74o007u0wv0dtgtrg3e	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:33.432
cmsagq8xy007v0wv0sr77esh0	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:35.782
cmsagq9g8007w0wv0l5jitdqp	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:36.44
cmsagqb4c007x0wv06us4wavl	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:38.604
cmsagqblh007y0wv0rv60p83j	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:39.221
cmsagqd3s007z0wv0k6yjq1fn	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 14:24:41.176
\.


--
-- Data for Name: Certificate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Certificate" (id, "userId", "courseId", "enrollmentId", "certificateNumber", "issueDate", "updatedAt", "deletedAt") FROM stdin;
cert_1	u_student_1	c_fundamentals	e_1	BN-1403-0001	2026-06-04 12:26:54.325	2026-08-01 12:26:54.325	\N
\.


--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Course" (id, title, subtitle, description, "mentorId", price, "originalPrice", level, category, "durationHours", lessons, rating, glyph, accent, published, "createdAt", "updatedAt", "deletedAt") FROM stdin;
c_fundamentals	مبانی فن بیان	از صفر تا تسلط بر صحبت کردن در جمع	نقطه شروع ایده‌آل برای آشنایی با اصول اولیه فن بیان، تکنیک‌های تنفسی و ساختار ارائه مؤثر.	u_teacher_1	850000	1200000	مقدماتی	speaking	18	64	4.9	🎤	violet	t	2026-01-13 12:26:54.279	2026-08-01 12:26:54.282	\N
c_presentation	استاد ارائه‌دهنده	ساخت و اجرای ارائه‌های تأثیرگذار	دوره‌ای جامع برای حرفه‌ای شدن در ارائه؛ از طراحی اسلاید تا داستان‌گویی و مدیریت سوالات.	u_teacher_2	1200000	\N	متوسط	presentation	24	82	4.8	📊	pink	t	2026-02-02 12:26:54.285	2026-08-01 12:26:54.286	\N
c_voice	آواسازی حرفه‌ای صدا	تکنیک‌های تنفسی و رسایی صدای جذاب	تکنیک‌های تخصصی برای زیباسازی، قدرتمندتر کردن و رسایی صدا.	u_teacher_1	980000	\N	متوسط	voice	16	48	4.9	🎙️	orchid	t	2026-02-22 12:26:54.288	2026-08-01 12:26:54.288	\N
c_leadership	سخنوری رهبران	هوش هیجانی و اقناع در رهبری	برای رهبران و مدیرانی که می‌خواهند کلامشان الهام‌بخش باشد.	u_teacher_1	1650000	\N	پیشرفته	speaking	28	96	5	👑	amber	t	2026-05-03 12:26:54.291	2026-08-01 12:26:54.292	\N
\.


--
-- Data for Name: CourseSearch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseSearch" (id, title, subtitle, "searchVector") FROM stdin;
c_fundamentals	مبانی فن بیان	از صفر تا تسلط بر صحبت کردن در جمع	'از':4 'بر':8 'بیان':3 'تا':6 'تسلط':7 'جمع':12 'در':11 'صحبت':9 'صفر':5 'فن':2 'مبانی':1 'کردن':10
c_presentation	استاد ارائه‌دهنده	ساخت و اجرای ارائه‌های تأثیرگذار	'اجرای':5 'ارائه‌دهنده':2 'ارائه‌های':6 'استاد':1 'تأثیرگذار':7 'ساخت':3 'و':4
c_voice	آواسازی حرفه‌ای صدا	تکنیک‌های تنفسی و رسایی صدای جذاب	'آواسازی':1 'تنفسی':5 'تکنیک‌های':4 'جذاب':9 'حرفه‌ای':2 'رسایی':7 'صدا':3 'صدای':8 'و':6
c_leadership	سخنوری رهبران	هوش هیجانی و اقناع در رهبری	'اقناع':6 'در':7 'رهبران':2 'رهبری':8 'سخنوری':1 'هوش':3 'هیجانی':4 'و':5
\.


--
-- Data for Name: EmailOutbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailOutbox" (id, "to", subject, html, status, retries, "maxRetries", "lastError", "nextAttemptAt", "createdAt", "sentAt", "updatedAt") FROM stdin;
cmsacwp34000cm8v0vbruqans	tester1785587854@baseerno.ir	خوش آمدید به بصیر نو	\n      <div style="\n  font-family: Vazirmatn, Tahoma, sans-serif;\n  direction: rtl;\n  text-align: right;\n  max-width: 600px;\n  margin: 0 auto;\n  padding: 32px;\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1px solid #e6e3f0;\n">\n        \n  <div style="text-align: center; margin-bottom: 24px;">\n    <div style="display: inline-block; padding: 12px 24px; background: linear-gradient(90deg, #1E3A5F, #2563EB, #D4A017, #F5C518); border-radius: 12px; color: white; font-size: 20px; font-weight: bold;">\n      بصیر نو\n    </div>\n  </div>\n\n        <h2 style="color: #0f172a; font-size: 22px;">سلام ????? ??? 1785587854 عزیز!</h2>\n        <p style="color: #4b5563; line-height: 1.8; font-size: 15px;">\n          ثبت‌نام شما در آکادمی بصیر نو با موفقیت انجام شد.\n          اکنون می‌توانید وارد پنل کاربری خود شوید و از دوره‌های آموزشی استفاده کنید.\n        </p>\n        <div style="text-align: center; margin: 24px 0;">\n          <a href="https://baseerno.ir/dashboard"\n             style="display: inline-block; padding: 12px 32px; background: linear-gradient(90deg, #1E3A5F, #2563EB); color: white; text-decoration: none; border-radius: 999px; font-weight: bold;">\n            ورود به پنل کاربری\n          </a>\n        </div>\n        \n  <div style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #e6e3f0; text-align: center; color: #6b7280; font-size: 12px;">\n    <p>آکادمی بصیر نو — یادگیری زبان انگلیسی، قدم به قدم</p>\n    <p>info@baseerno.ir | ۰۹۳۰-۷۷۲-۵۴۸۴</p>\n  </div>\n\n      </div>\n    	pending	0	3	\N	\N	2026-08-01 12:37:38.176	\N	2026-08-01 12:37:38.176
cmsacxcga000km8v0jufrnfnn	student@baseerno.ir	تأیید پرداخت — سخنوری رهبران	\n      <div style="\n  font-family: Vazirmatn, Tahoma, sans-serif;\n  direction: rtl;\n  text-align: right;\n  max-width: 600px;\n  margin: 0 auto;\n  padding: 32px;\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1px solid #e6e3f0;\n">\n        \n  <div style="text-align: center; margin-bottom: 24px;">\n    <div style="display: inline-block; padding: 12px 24px; background: linear-gradient(90deg, #1E3A5F, #2563EB, #D4A017, #F5C518); border-radius: 12px; color: white; font-size: 20px; font-weight: bold;">\n      بصیر نو\n    </div>\n  </div>\n\n        <h2 style="color: #0f172a; font-size: 22px;">پرداخت شما تأیید شد!</h2>\n        <p style="color: #4b5563; line-height: 1.8; font-size: 15px;">\n          نیما رستگار عزیز، پرداخت شما برای دوره <strong>سخنوری رهبران</strong> با موفقیت انجام شد.\n        </p>\n        <div style="background: #f5f3fa; border-radius: 12px; padding: 16px; margin: 16px 0;">\n          <p style="margin: 0; color: #4b5563; font-size: 14px;">\n            <strong>دوره:</strong> سخنوری رهبران<br/>\n            <strong>مبلغ:</strong> ۱٬۶۵۰٬۰۰۰ تومان<br/>\n            <strong>وضعیت:</strong> <span style="color: #15803d;">پرداخت موفق</span>\n          </p>\n        </div>\n        <div style="text-align: center; margin: 24px 0;">\n          <a href="https://baseerno.ir/dashboard/courses"\n             style="display: inline-block; padding: 12px 32px; background: linear-gradient(90deg, #1E3A5F, #2563EB); color: white; text-decoration: none; border-radius: 999px; font-weight: bold;">\n            مشاهده دوره\n          </a>\n        </div>\n        \n  <div style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #e6e3f0; text-align: center; color: #6b7280; font-size: 12px;">\n    <p>آکادمی بصیر نو — یادگیری زبان انگلیسی، قدم به قدم</p>\n    <p>info@baseerno.ir | ۰۹۳۰-۷۷۲-۵۴۸۴</p>\n  </div>\n\n      </div>\n    	pending	0	3	\N	\N	2026-08-01 12:38:08.458	\N	2026-08-01 12:38:08.458
\.


--
-- Data for Name: Enrollment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Enrollment" (id, "userId", "courseId", progress, status, "enrolledAt", "completedAt", "updatedAt", "deletedAt") FROM stdin;
e_1	u_student_1	c_fundamentals	100	COMPLETED	2026-04-23 12:26:54.303	2026-06-02 12:26:54.303	2026-08-01 12:26:54.304	\N
e_2	u_student_1	c_presentation	65	ACTIVE	2026-06-22 12:26:54.307	\N	2026-08-01 12:26:54.308	\N
e_3	u_student_1	c_voice	20	ACTIVE	2026-07-22 12:26:54.311	\N	2026-08-01 12:26:54.311	\N
e_4	u_student_2	c_fundamentals	80	ACTIVE	2026-06-12 12:26:54.313	\N	2026-08-01 12:26:54.313	\N
e_5	u_student_3	c_voice	35	ACTIVE	2026-07-02 12:26:54.316	\N	2026-08-01 12:26:54.316	\N
\.


--
-- Data for Name: Grade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Grade" (id, "userId", "courseId", "enrollmentId", score, feedback, "gradedAt", "teacherId", "updatedAt", "deletedAt") FROM stdin;
g_1	u_student_1	c_fundamentals	e_1	18.5	پیشرفت عالی در کنترل صدا و زبان بدن.	2026-06-04 12:26:54.318	u_teacher_1	2026-08-01 12:26:54.319	\N
g_2	u_student_2	c_fundamentals	e_4	17	تمرینات را ادامه بده.	2026-07-12 12:26:54.322	u_teacher_1	2026-08-01 12:26:54.323	\N
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lesson" (id, "courseId", title, type, "videoUrl", "durationMinutes", "sortOrder", "isFree", published, "createdAt", "updatedAt", "deletedAt") FROM stdin;
l_1	c_fundamentals	مقدمه: چرا فن بیان؟	video	https://www.youtube.com/embed/ScMzIvxBSi4	8	1	t	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
l_2	c_fundamentals	تکنیک‌های تنفسی	video	https://www.youtube.com/embed/ScMzIvxBSi4	12	2	f	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
l_3	c_fundamentals	ساختار یک ارائه	video	https://www.youtube.com/embed/ScMzIvxBSi4	15	3	f	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
\.


--
-- Data for Name: LoadRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoadRun" (id, "baseUrl", vus, "durationSeconds", pass, scenarios, "cacheHits", "createdAt") FROM stdin;
cmsags10g0000lcv0jj4ctxqh	http://127.0.0.1:8088	20	60	f	{"auth": {"avg": 455, "p50": 288, "p90": 1030, "p95": 1255, "errors": 0}, "browse": {"avg": 51, "p50": 12, "p90": 144, "p95": 170, "errors": 0}, "search": {"avg": 127, "p50": 23, "p90": 430, "p95": 509, "errors": 0}, "dashboard": {"avg": 198, "p50": 117, "p90": 410, "p95": 787, "errors": 0}}	420	2026-08-01 14:25:58.816
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Message" (id, "senderId", "receiverId", body, read, "sentAt", "updatedAt", "deletedAt") FROM stdin;
m_1	u_teacher_1	u_student_1	آفرین! گواهی دوره مبانی برای شما صادر شد. موفق باشی.	f	2026-06-05 12:26:54.335	2026-08-01 12:26:54.336	\N
m_2	u_admin_1	u_student_1	به پلتفرم بصیر نو خوش آمدید. در صورت نیاز به راهنمایی در تماس باشید.	t	2026-04-23 12:26:54.335	2026-08-01 12:26:54.336	\N
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, "userId", type, title, body, read, link, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordReset" (id, "userId", token, "expiresAt", used, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (id, "userId", "courseId", amount, status, method, "paidAt", "createdAt", "updatedAt", "deletedAt", "gatewayAuthority", "gatewayRefId") FROM stdin;
p_1	u_student_1	c_fundamentals	850000	PAID	زرین‌پال	2026-04-23 12:26:54.329	2026-04-23 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_2	u_student_1	c_presentation	1200000	PAID	بانک سامان	2026-06-22 12:26:54.329	2026-06-22 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_3	u_student_1	c_voice	980000	PAID	زرین‌پال	2026-07-22 12:26:54.329	2026-07-22 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_4	u_student_2	c_fundamentals	850000	PAID	زرین‌پال	2026-06-12 12:26:54.329	2026-06-12 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_5	u_student_3	c_voice	980000	PENDING	زرین‌پال	\N	2026-07-27 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, email, "passwordHash", role, avatar, phone, bio, "createdAt", "updatedAt", "deletedAt", "twoFactorSecret", "twoFactorEnabled") FROM stdin;
u_student_1	نیما رستگار	student@baseerno.ir	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000001	دانشجوی فن بیان، علاقه‌مند به سخنرانی حرفه‌ای.	2026-04-03 12:26:54.246	2026-08-01 12:26:54.258	\N	\N	f
u_teacher_1	دکتر سارا محمدی	teacher@baseerno.ir	$2b$12$zGlwX4M67JYaDXr8IvQyH.4wpcS491t6K9k4qJ7vQh0p.4ikJuO62	TEACHER	\N	09120000002	دکترای علوم ارتباطات، مدرس فن بیان با ۱۲ سال تجربه.	2025-10-05 12:26:54.266	2026-08-01 12:26:54.267	\N	\N	f
u_admin_1	مدیر سیستم	admin@baseerno.ir	$2b$12$RQ3ygmzWpuOnNVVcjJoczu10T.ye2mChUBDXavzBdqOZrw1Ti.SMW	ADMIN	\N	09120000003	مدیریت پلتفرم بصیر نو.	2025-06-27 12:26:54.269	2026-08-01 12:26:54.27	\N	\N	f
u_student_2	مریم احمدی	maryam@example.com	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000011	\N	2026-05-13 12:26:54.272	2026-08-01 12:26:54.273	\N	\N	f
u_student_3	علی کریمی	ali@example.com	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000012	\N	2026-06-17 12:26:54.275	2026-08-01 12:26:54.275	\N	\N	f
u_teacher_2	مهندس رضا کریمی	reza@example.com	$2b$12$zGlwX4M67JYaDXr8IvQyH.4wpcS491t6K9k4qJ7vQh0p.4ikJuO62	TEACHER	\N	09120000022	مدرس ارائه و ارتباطات سازمانی.	2025-11-24 12:26:54.276	2026-08-01 12:26:54.277	\N	\N	f
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
1399592a-8a9d-49ed-9a2a-fa8e922d7244	d253c345027fc92f979dacd8b3f8e64e9542bcedcaa658c2f742c48362787e9a	2026-08-01 15:56:42.638864+03:30	20260101000000_init	\N	\N	2026-08-01 15:56:42.473463+03:30	1
dcd0807c-3060-45b0-8b39-bbd1c435b72e	11432932ce4c145ef1e847edfcf80f6ae71b39b70ab52929d1347f4c8bfe1216	2026-08-01 15:56:42.642839+03:30	20260725000000_payment_gateway_fields	\N	\N	2026-08-01 15:56:42.639193+03:30	1
5cbbfa05-b635-4507-914e-57fd2bd436ab	5d28a296fa2876e156c92a47c596c45a9fb7a60a0c21f2b3eaaa816a60b449b4	2026-08-01 15:56:42.651004+03:30	20260731000000_add_course_search	\N	\N	2026-08-01 15:56:42.643112+03:30	1
63f4e093-6060-43e7-a1d3-1d3f0ddec181	026677395d58b7521de02205e866bb016e631f0b4418fb75c71b17d2d71b989f	2026-08-01 15:56:42.659643+03:30	20260731000001_add_email_outbox	\N	\N	2026-08-01 15:56:42.651382+03:30	1
110eb425-e09a-4eb1-91ac-46579c54aade	b0d989aa8982b66cd8744abf068ba9933b162658824cd068b96d83c2f342834c	2026-08-01 15:56:42.673999+03:30	20260731000002_add_audit_log_and_2fa	\N	\N	2026-08-01 15:56:42.659982+03:30	1
07e4a421-f118-4e9f-a617-ce2b3d6a58ad	c2d3a9bcefe809ab1cc038e6ed67a35abf1041e073e3230664dbc14a24fdd8e0	2026-08-01 15:56:42.683608+03:30	20260731000003_add_load_run	\N	\N	2026-08-01 15:56:42.674478+03:30	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Certificate Certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_pkey" PRIMARY KEY (id);


--
-- Name: CourseSearch CourseSearch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseSearch"
    ADD CONSTRAINT "CourseSearch_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: EmailOutbox EmailOutbox_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailOutbox"
    ADD CONSTRAINT "EmailOutbox_pkey" PRIMARY KEY (id);


--
-- Name: Enrollment Enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_pkey" PRIMARY KEY (id);


--
-- Name: Grade Grade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: LoadRun LoadRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoadRun"
    ADD CONSTRAINT "LoadRun_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_action_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_action_createdAt_idx" ON public."AuditLog" USING btree (action, "createdAt");


--
-- Name: AuditLog_actorId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_actorId_createdAt_idx" ON public."AuditLog" USING btree ("actorId", "createdAt");


--
-- Name: AuditLog_targetType_targetId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_targetType_targetId_idx" ON public."AuditLog" USING btree ("targetType", "targetId");


--
-- Name: Certificate_certificateNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Certificate_certificateNumber_key" ON public."Certificate" USING btree ("certificateNumber");


--
-- Name: Certificate_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Certificate_deletedAt_idx" ON public."Certificate" USING btree ("deletedAt");


--
-- Name: Certificate_enrollmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Certificate_enrollmentId_key" ON public."Certificate" USING btree ("enrollmentId");


--
-- Name: Certificate_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Certificate_userId_idx" ON public."Certificate" USING btree ("userId");


--
-- Name: Course_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_category_idx" ON public."Course" USING btree (category);


--
-- Name: Course_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_deletedAt_idx" ON public."Course" USING btree ("deletedAt");


--
-- Name: Course_mentorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_mentorId_idx" ON public."Course" USING btree ("mentorId");


--
-- Name: Course_published_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_published_idx" ON public."Course" USING btree (published);


--
-- Name: EmailOutbox_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailOutbox_status_createdAt_idx" ON public."EmailOutbox" USING btree (status, "createdAt");


--
-- Name: Enrollment_courseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_courseId_idx" ON public."Enrollment" USING btree ("courseId");


--
-- Name: Enrollment_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_deletedAt_idx" ON public."Enrollment" USING btree ("deletedAt");


--
-- Name: Enrollment_userId_courseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Enrollment_userId_courseId_key" ON public."Enrollment" USING btree ("userId", "courseId");


--
-- Name: Enrollment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_userId_idx" ON public."Enrollment" USING btree ("userId");


--
-- Name: Grade_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_deletedAt_idx" ON public."Grade" USING btree ("deletedAt");


--
-- Name: Grade_enrollmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_enrollmentId_idx" ON public."Grade" USING btree ("enrollmentId");


--
-- Name: Grade_teacherId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_teacherId_idx" ON public."Grade" USING btree ("teacherId");


--
-- Name: Grade_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_userId_idx" ON public."Grade" USING btree ("userId");


--
-- Name: Lesson_courseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_courseId_idx" ON public."Lesson" USING btree ("courseId");


--
-- Name: Lesson_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_deletedAt_idx" ON public."Lesson" USING btree ("deletedAt");


--
-- Name: Lesson_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_sortOrder_idx" ON public."Lesson" USING btree ("sortOrder");


--
-- Name: LoadRun_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoadRun_createdAt_idx" ON public."LoadRun" USING btree ("createdAt");


--
-- Name: Message_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_deletedAt_idx" ON public."Message" USING btree ("deletedAt");


--
-- Name: Message_receiverId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_receiverId_idx" ON public."Message" USING btree ("receiverId");


--
-- Name: Message_senderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_senderId_idx" ON public."Message" USING btree ("senderId");


--
-- Name: Notification_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_deletedAt_idx" ON public."Notification" USING btree ("deletedAt");


--
-- Name: Notification_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_read_idx" ON public."Notification" USING btree (read);


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: PasswordReset_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_deletedAt_idx" ON public."PasswordReset" USING btree ("deletedAt");


--
-- Name: PasswordReset_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_token_idx" ON public."PasswordReset" USING btree (token);


--
-- Name: PasswordReset_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordReset_token_key" ON public."PasswordReset" USING btree (token);


--
-- Name: PasswordReset_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_userId_idx" ON public."PasswordReset" USING btree ("userId");


--
-- Name: Payment_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_deletedAt_idx" ON public."Payment" USING btree ("deletedAt");


--
-- Name: Payment_gatewayAuthority_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Payment_gatewayAuthority_key" ON public."Payment" USING btree ("gatewayAuthority");


--
-- Name: Payment_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_status_idx" ON public."Payment" USING btree (status);


--
-- Name: Payment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_userId_idx" ON public."Payment" USING btree ("userId");


--
-- Name: User_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_deletedAt_idx" ON public."User" USING btree ("deletedAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: course_search_gin_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX course_search_gin_idx ON public."CourseSearch" USING gin ("searchVector");


--
-- Name: Certificate Certificate_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Certificate Certificate_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Certificate Certificate_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Course Course_mentorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Enrollment Enrollment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Enrollment Enrollment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Lesson Lesson_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict qBfJMPCGfeiUVl2REY8TiKbT8meIdXAT1GVfeQGvKpwm7k3IWrnoTUOpwn5ecay

