--
-- PostgreSQL database dump
--

\restrict 32ryI1gNLfEUeHkhTD1LwY9cAV5TDLOLPzUZuSppAcFRDuCfAlLRxpFnIyIXlYu

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: EnrollmentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EnrollmentStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'DROPPED'
);


ALTER TYPE public."EnrollmentStatus" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'STUDENT',
    'TEACHER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "actorId" text,
    action text NOT NULL,
    "targetType" text NOT NULL,
    "targetId" text,
    meta jsonb,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: Certificate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Certificate" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    "enrollmentId" text NOT NULL,
    "certificateNumber" text NOT NULL,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Certificate" OWNER TO postgres;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Course" (
    id text NOT NULL,
    title text NOT NULL,
    subtitle text NOT NULL,
    description text NOT NULL,
    "mentorId" text NOT NULL,
    price integer,
    "originalPrice" integer,
    level text DEFAULT 'مقدماتی'::text NOT NULL,
    category text NOT NULL,
    "durationHours" integer NOT NULL,
    lessons integer NOT NULL,
    rating double precision DEFAULT 0 NOT NULL,
    glyph text NOT NULL,
    accent text NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Course" OWNER TO postgres;

--
-- Name: CourseSearch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseSearch" (
    id text NOT NULL,
    title text NOT NULL,
    subtitle text NOT NULL,
    "searchVector" tsvector
);


ALTER TABLE public."CourseSearch" OWNER TO postgres;

--
-- Name: EmailOutbox; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailOutbox" (
    id text NOT NULL,
    "to" text NOT NULL,
    subject text NOT NULL,
    html text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "lastError" text,
    "nextAttemptAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailOutbox" OWNER TO postgres;

--
-- Name: Enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Enrollment" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    status public."EnrollmentStatus" DEFAULT 'ACTIVE'::public."EnrollmentStatus" NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Enrollment" OWNER TO postgres;

--
-- Name: Grade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Grade" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    "enrollmentId" text NOT NULL,
    score double precision NOT NULL,
    feedback text,
    "gradedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "teacherId" text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Grade" OWNER TO postgres;

--
-- Name: Lesson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lesson" (
    id text NOT NULL,
    "courseId" text NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'video'::text NOT NULL,
    "videoUrl" text,
    "durationMinutes" integer NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isFree" boolean DEFAULT false NOT NULL,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Lesson" OWNER TO postgres;

--
-- Name: LoadRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoadRun" (
    id text NOT NULL,
    "baseUrl" text NOT NULL,
    vus integer NOT NULL,
    "durationSeconds" integer NOT NULL,
    pass boolean NOT NULL,
    scenarios jsonb NOT NULL,
    "cacheHits" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoadRun" OWNER TO postgres;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    body text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Message" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    link text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "courseId" text NOT NULL,
    amount integer NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    method text NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "gatewayAuthority" text,
    "gatewayRefId" text
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'STUDENT'::public."Role" NOT NULL,
    avatar text,
    phone text,
    bio text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "twoFactorSecret" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "actorId", action, "targetType", "targetId", meta, ip, "createdAt") FROM stdin;
cmsacjyw60005m8v0b6af83vk	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:27:44.358
cmsacldgm0006m8v0ocmoh0px	u_admin_1	auth.login	User	u_admin_1	\N	\N	2026-08-01 12:28:49.894
cmsacuih60007m8v0d8x4z3nu	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:35:56.298
cmsacuipx0008m8v0jm03nq2x	u_teacher_1	auth.login	User	u_teacher_1	\N	\N	2026-08-01 12:35:56.613
cmsacuiyk0009m8v04tjzf28b	u_admin_1	auth.login	User	u_admin_1	\N	\N	2026-08-01 12:35:56.925
cmsacwp33000bm8v09aroopbt	cmsacwp14000am8v0w51dhs9w	auth.register	User	cmsacwp14000am8v0w51dhs9w	{"email": "tester1785587854@baseerno.ir"}	\N	2026-08-01 12:37:38.175
cmsacwpk1000em8v0smp7ztx7	u_student_1	payment.created	Course	c_leadership	{"amount": 1650000}	\N	2026-08-01 12:37:38.785
cmsacxc4e000gm8v0lmrnoq3p	u_student_1	payment.created	Course	c_leadership	{"amount": 1650000}	\N	2026-08-01 12:38:08.03
cmsad41lk000pm8v0hnihjyzw	u_student_1	auth.login	User	u_student_1	\N	\N	2026-08-01 12:43:20.984
\.


--
-- Data for Name: Certificate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Certificate" (id, "userId", "courseId", "enrollmentId", "certificateNumber", "issueDate", "updatedAt", "deletedAt") FROM stdin;
cert_1	u_student_1	c_fundamentals	e_1	BN-1403-0001	2026-06-04 12:26:54.325	2026-08-01 12:26:54.325	\N
\.


--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Course" (id, title, subtitle, description, "mentorId", price, "originalPrice", level, category, "durationHours", lessons, rating, glyph, accent, published, "createdAt", "updatedAt", "deletedAt") FROM stdin;
c_fundamentals	مبانی فن بیان	از صفر تا تسلط بر صحبت کردن در جمع	نقطه شروع ایده‌آل برای آشنایی با اصول اولیه فن بیان، تکنیک‌های تنفسی و ساختار ارائه مؤثر.	u_teacher_1	850000	1200000	مقدماتی	speaking	18	64	4.9	🎤	violet	t	2026-01-13 12:26:54.279	2026-08-01 12:26:54.282	\N
c_presentation	استاد ارائه‌دهنده	ساخت و اجرای ارائه‌های تأثیرگذار	دوره‌ای جامع برای حرفه‌ای شدن در ارائه؛ از طراحی اسلاید تا داستان‌گویی و مدیریت سوالات.	u_teacher_2	1200000	\N	متوسط	presentation	24	82	4.8	📊	pink	t	2026-02-02 12:26:54.285	2026-08-01 12:26:54.286	\N
c_voice	آواسازی حرفه‌ای صدا	تکنیک‌های تنفسی و رسایی صدای جذاب	تکنیک‌های تخصصی برای زیباسازی، قدرتمندتر کردن و رسایی صدا.	u_teacher_1	980000	\N	متوسط	voice	16	48	4.9	🎙️	orchid	t	2026-02-22 12:26:54.288	2026-08-01 12:26:54.288	\N
c_leadership	سخنوری رهبران	هوش هیجانی و اقناع در رهبری	برای رهبران و مدیرانی که می‌خواهند کلامشان الهام‌بخش باشد.	u_teacher_1	1650000	\N	پیشرفته	speaking	28	96	5	👑	amber	t	2026-05-03 12:26:54.291	2026-08-01 12:26:54.292	\N
\.


--
-- Data for Name: CourseSearch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseSearch" (id, title, subtitle, "searchVector") FROM stdin;
\.


--
-- Data for Name: EmailOutbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailOutbox" (id, "to", subject, html, status, retries, "maxRetries", "lastError", "nextAttemptAt", "createdAt", "sentAt", "updatedAt") FROM stdin;
cmsacwp34000cm8v0vbruqans	tester1785587854@baseerno.ir	خوش آمدید به بصیر نو	\n      <div style="\n  font-family: Vazirmatn, Tahoma, sans-serif;\n  direction: rtl;\n  text-align: right;\n  max-width: 600px;\n  margin: 0 auto;\n  padding: 32px;\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1px solid #e6e3f0;\n">\n        \n  <div style="text-align: center; margin-bottom: 24px;">\n    <div style="display: inline-block; padding: 12px 24px; background: linear-gradient(90deg, #1E3A5F, #2563EB, #D4A017, #F5C518); border-radius: 12px; color: white; font-size: 20px; font-weight: bold;">\n      بصیر نو\n    </div>\n  </div>\n\n        <h2 style="color: #0f172a; font-size: 22px;">سلام ????? ??? 1785587854 عزیز!</h2>\n        <p style="color: #4b5563; line-height: 1.8; font-size: 15px;">\n          ثبت‌نام شما در آکادمی بصیر نو با موفقیت انجام شد.\n          اکنون می‌توانید وارد پنل کاربری خود شوید و از دوره‌های آموزشی استفاده کنید.\n        </p>\n        <div style="text-align: center; margin: 24px 0;">\n          <a href="https://baseerno.ir/dashboard"\n             style="display: inline-block; padding: 12px 32px; background: linear-gradient(90deg, #1E3A5F, #2563EB); color: white; text-decoration: none; border-radius: 999px; font-weight: bold;">\n            ورود به پنل کاربری\n          </a>\n        </div>\n        \n  <div style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #e6e3f0; text-align: center; color: #6b7280; font-size: 12px;">\n    <p>آکادمی بصیر نو — یادگیری زبان انگلیسی، قدم به قدم</p>\n    <p>info@baseerno.ir | ۰۹۳۰-۷۷۲-۵۴۸۴</p>\n  </div>\n\n      </div>\n    	pending	0	3	\N	\N	2026-08-01 12:37:38.176	\N	2026-08-01 12:37:38.176
cmsacxcga000km8v0jufrnfnn	student@baseerno.ir	تأیید پرداخت — سخنوری رهبران	\n      <div style="\n  font-family: Vazirmatn, Tahoma, sans-serif;\n  direction: rtl;\n  text-align: right;\n  max-width: 600px;\n  margin: 0 auto;\n  padding: 32px;\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1px solid #e6e3f0;\n">\n        \n  <div style="text-align: center; margin-bottom: 24px;">\n    <div style="display: inline-block; padding: 12px 24px; background: linear-gradient(90deg, #1E3A5F, #2563EB, #D4A017, #F5C518); border-radius: 12px; color: white; font-size: 20px; font-weight: bold;">\n      بصیر نو\n    </div>\n  </div>\n\n        <h2 style="color: #0f172a; font-size: 22px;">پرداخت شما تأیید شد!</h2>\n        <p style="color: #4b5563; line-height: 1.8; font-size: 15px;">\n          نیما رستگار عزیز، پرداخت شما برای دوره <strong>سخنوری رهبران</strong> با موفقیت انجام شد.\n        </p>\n        <div style="background: #f5f3fa; border-radius: 12px; padding: 16px; margin: 16px 0;">\n          <p style="margin: 0; color: #4b5563; font-size: 14px;">\n            <strong>دوره:</strong> سخنوری رهبران<br/>\n            <strong>مبلغ:</strong> ۱٬۶۵۰٬۰۰۰ تومان<br/>\n            <strong>وضعیت:</strong> <span style="color: #15803d;">پرداخت موفق</span>\n          </p>\n        </div>\n        <div style="text-align: center; margin: 24px 0;">\n          <a href="https://baseerno.ir/dashboard/courses"\n             style="display: inline-block; padding: 12px 32px; background: linear-gradient(90deg, #1E3A5F, #2563EB); color: white; text-decoration: none; border-radius: 999px; font-weight: bold;">\n            مشاهده دوره\n          </a>\n        </div>\n        \n  <div style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #e6e3f0; text-align: center; color: #6b7280; font-size: 12px;">\n    <p>آکادمی بصیر نو — یادگیری زبان انگلیسی، قدم به قدم</p>\n    <p>info@baseerno.ir | ۰۹۳۰-۷۷۲-۵۴۸۴</p>\n  </div>\n\n      </div>\n    	pending	0	3	\N	\N	2026-08-01 12:38:08.458	\N	2026-08-01 12:38:08.458
\.


--
-- Data for Name: Enrollment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Enrollment" (id, "userId", "courseId", progress, status, "enrolledAt", "completedAt", "updatedAt", "deletedAt") FROM stdin;
e_1	u_student_1	c_fundamentals	100	COMPLETED	2026-04-23 12:26:54.303	2026-06-02 12:26:54.303	2026-08-01 12:26:54.304	\N
e_2	u_student_1	c_presentation	65	ACTIVE	2026-06-22 12:26:54.307	\N	2026-08-01 12:26:54.308	\N
e_3	u_student_1	c_voice	20	ACTIVE	2026-07-22 12:26:54.311	\N	2026-08-01 12:26:54.311	\N
e_4	u_student_2	c_fundamentals	80	ACTIVE	2026-06-12 12:26:54.313	\N	2026-08-01 12:26:54.313	\N
e_5	u_student_3	c_voice	35	ACTIVE	2026-07-02 12:26:54.316	\N	2026-08-01 12:26:54.316	\N
\.


--
-- Data for Name: Grade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Grade" (id, "userId", "courseId", "enrollmentId", score, feedback, "gradedAt", "teacherId", "updatedAt", "deletedAt") FROM stdin;
g_1	u_student_1	c_fundamentals	e_1	18.5	پیشرفت عالی در کنترل صدا و زبان بدن.	2026-06-04 12:26:54.318	u_teacher_1	2026-08-01 12:26:54.319	\N
g_2	u_student_2	c_fundamentals	e_4	17	تمرینات را ادامه بده.	2026-07-12 12:26:54.322	u_teacher_1	2026-08-01 12:26:54.323	\N
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lesson" (id, "courseId", title, type, "videoUrl", "durationMinutes", "sortOrder", "isFree", published, "createdAt", "updatedAt", "deletedAt") FROM stdin;
l_1	c_fundamentals	مقدمه: چرا فن بیان؟	video	https://www.youtube.com/embed/ScMzIvxBSi4	8	1	t	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
l_2	c_fundamentals	تکنیک‌های تنفسی	video	https://www.youtube.com/embed/ScMzIvxBSi4	12	2	f	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
l_3	c_fundamentals	ساختار یک ارائه	video	https://www.youtube.com/embed/ScMzIvxBSi4	15	3	f	t	2026-08-01 12:26:54.299	2026-08-01 12:26:54.299	\N
\.


--
-- Data for Name: LoadRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoadRun" (id, "baseUrl", vus, "durationSeconds", pass, scenarios, "cacheHits", "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Message" (id, "senderId", "receiverId", body, read, "sentAt", "updatedAt", "deletedAt") FROM stdin;
m_1	u_teacher_1	u_student_1	آفرین! گواهی دوره مبانی برای شما صادر شد. موفق باشی.	f	2026-06-05 12:26:54.335	2026-08-01 12:26:54.336	\N
m_2	u_admin_1	u_student_1	به پلتفرم بصیر نو خوش آمدید. در صورت نیاز به راهنمایی در تماس باشید.	t	2026-04-23 12:26:54.335	2026-08-01 12:26:54.336	\N
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, "userId", type, title, body, read, link, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordReset" (id, "userId", token, "expiresAt", used, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (id, "userId", "courseId", amount, status, method, "paidAt", "createdAt", "updatedAt", "deletedAt", "gatewayAuthority", "gatewayRefId") FROM stdin;
p_1	u_student_1	c_fundamentals	850000	PAID	زرین‌پال	2026-04-23 12:26:54.329	2026-04-23 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_2	u_student_1	c_presentation	1200000	PAID	بانک سامان	2026-06-22 12:26:54.329	2026-06-22 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_3	u_student_1	c_voice	980000	PAID	زرین‌پال	2026-07-22 12:26:54.329	2026-07-22 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_4	u_student_2	c_fundamentals	850000	PAID	زرین‌پال	2026-06-12 12:26:54.329	2026-06-12 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
p_5	u_student_3	c_voice	980000	PENDING	زرین‌پال	\N	2026-07-27 12:26:54.329	2026-08-01 12:26:54.331	\N	\N	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, email, "passwordHash", role, avatar, phone, bio, "createdAt", "updatedAt", "deletedAt", "twoFactorSecret", "twoFactorEnabled") FROM stdin;
u_student_1	نیما رستگار	student@baseerno.ir	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000001	دانشجوی فن بیان، علاقه‌مند به سخنرانی حرفه‌ای.	2026-04-03 12:26:54.246	2026-08-01 12:26:54.258	\N	\N	f
u_teacher_1	دکتر سارا محمدی	teacher@baseerno.ir	$2b$12$zGlwX4M67JYaDXr8IvQyH.4wpcS491t6K9k4qJ7vQh0p.4ikJuO62	TEACHER	\N	09120000002	دکترای علوم ارتباطات، مدرس فن بیان با ۱۲ سال تجربه.	2025-10-05 12:26:54.266	2026-08-01 12:26:54.267	\N	\N	f
u_admin_1	مدیر سیستم	admin@baseerno.ir	$2b$12$RQ3ygmzWpuOnNVVcjJoczu10T.ye2mChUBDXavzBdqOZrw1Ti.SMW	ADMIN	\N	09120000003	مدیریت پلتفرم بصیر نو.	2025-06-27 12:26:54.269	2026-08-01 12:26:54.27	\N	\N	f
u_student_2	مریم احمدی	maryam@example.com	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000011	\N	2026-05-13 12:26:54.272	2026-08-01 12:26:54.273	\N	\N	f
u_student_3	علی کریمی	ali@example.com	$2b$12$dfTRc448mCD/gx/Cg7vVs.xCPwjY7KiAHPKm/MJkSWILe8PnviaMO	STUDENT	\N	09120000012	\N	2026-06-17 12:26:54.275	2026-08-01 12:26:54.275	\N	\N	f
u_teacher_2	مهندس رضا کریمی	reza@example.com	$2b$12$zGlwX4M67JYaDXr8IvQyH.4wpcS491t6K9k4qJ7vQh0p.4ikJuO62	TEACHER	\N	09120000022	مدرس ارائه و ارتباطات سازمانی.	2025-11-24 12:26:54.276	2026-08-01 12:26:54.277	\N	\N	f
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
1399592a-8a9d-49ed-9a2a-fa8e922d7244	d253c345027fc92f979dacd8b3f8e64e9542bcedcaa658c2f742c48362787e9a	2026-08-01 15:56:42.638864+03:30	20260101000000_init	\N	\N	2026-08-01 15:56:42.473463+03:30	1
dcd0807c-3060-45b0-8b39-bbd1c435b72e	11432932ce4c145ef1e847edfcf80f6ae71b39b70ab52929d1347f4c8bfe1216	2026-08-01 15:56:42.642839+03:30	20260725000000_payment_gateway_fields	\N	\N	2026-08-01 15:56:42.639193+03:30	1
5cbbfa05-b635-4507-914e-57fd2bd436ab	5d28a296fa2876e156c92a47c596c45a9fb7a60a0c21f2b3eaaa816a60b449b4	2026-08-01 15:56:42.651004+03:30	20260731000000_add_course_search	\N	\N	2026-08-01 15:56:42.643112+03:30	1
63f4e093-6060-43e7-a1d3-1d3f0ddec181	026677395d58b7521de02205e866bb016e631f0b4418fb75c71b17d2d71b989f	2026-08-01 15:56:42.659643+03:30	20260731000001_add_email_outbox	\N	\N	2026-08-01 15:56:42.651382+03:30	1
110eb425-e09a-4eb1-91ac-46579c54aade	b0d989aa8982b66cd8744abf068ba9933b162658824cd068b96d83c2f342834c	2026-08-01 15:56:42.673999+03:30	20260731000002_add_audit_log_and_2fa	\N	\N	2026-08-01 15:56:42.659982+03:30	1
07e4a421-f118-4e9f-a617-ce2b3d6a58ad	c2d3a9bcefe809ab1cc038e6ed67a35abf1041e073e3230664dbc14a24fdd8e0	2026-08-01 15:56:42.683608+03:30	20260731000003_add_load_run	\N	\N	2026-08-01 15:56:42.674478+03:30	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Certificate Certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_pkey" PRIMARY KEY (id);


--
-- Name: CourseSearch CourseSearch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseSearch"
    ADD CONSTRAINT "CourseSearch_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: EmailOutbox EmailOutbox_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailOutbox"
    ADD CONSTRAINT "EmailOutbox_pkey" PRIMARY KEY (id);


--
-- Name: Enrollment Enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_pkey" PRIMARY KEY (id);


--
-- Name: Grade Grade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: LoadRun LoadRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoadRun"
    ADD CONSTRAINT "LoadRun_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_action_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_action_createdAt_idx" ON public."AuditLog" USING btree (action, "createdAt");


--
-- Name: AuditLog_actorId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_actorId_createdAt_idx" ON public."AuditLog" USING btree ("actorId", "createdAt");


--
-- Name: AuditLog_targetType_targetId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_targetType_targetId_idx" ON public."AuditLog" USING btree ("targetType", "targetId");


--
-- Name: Certificate_certificateNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Certificate_certificateNumber_key" ON public."Certificate" USING btree ("certificateNumber");


--
-- Name: Certificate_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Certificate_deletedAt_idx" ON public."Certificate" USING btree ("deletedAt");


--
-- Name: Certificate_enrollmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Certificate_enrollmentId_key" ON public."Certificate" USING btree ("enrollmentId");


--
-- Name: Certificate_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Certificate_userId_idx" ON public."Certificate" USING btree ("userId");


--
-- Name: Course_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_category_idx" ON public."Course" USING btree (category);


--
-- Name: Course_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_deletedAt_idx" ON public."Course" USING btree ("deletedAt");


--
-- Name: Course_mentorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_mentorId_idx" ON public."Course" USING btree ("mentorId");


--
-- Name: Course_published_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Course_published_idx" ON public."Course" USING btree (published);


--
-- Name: EmailOutbox_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailOutbox_status_createdAt_idx" ON public."EmailOutbox" USING btree (status, "createdAt");


--
-- Name: Enrollment_courseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_courseId_idx" ON public."Enrollment" USING btree ("courseId");


--
-- Name: Enrollment_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_deletedAt_idx" ON public."Enrollment" USING btree ("deletedAt");


--
-- Name: Enrollment_userId_courseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Enrollment_userId_courseId_key" ON public."Enrollment" USING btree ("userId", "courseId");


--
-- Name: Enrollment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Enrollment_userId_idx" ON public."Enrollment" USING btree ("userId");


--
-- Name: Grade_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_deletedAt_idx" ON public."Grade" USING btree ("deletedAt");


--
-- Name: Grade_enrollmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_enrollmentId_idx" ON public."Grade" USING btree ("enrollmentId");


--
-- Name: Grade_teacherId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_teacherId_idx" ON public."Grade" USING btree ("teacherId");


--
-- Name: Grade_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Grade_userId_idx" ON public."Grade" USING btree ("userId");


--
-- Name: Lesson_courseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_courseId_idx" ON public."Lesson" USING btree ("courseId");


--
-- Name: Lesson_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_deletedAt_idx" ON public."Lesson" USING btree ("deletedAt");


--
-- Name: Lesson_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Lesson_sortOrder_idx" ON public."Lesson" USING btree ("sortOrder");


--
-- Name: LoadRun_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoadRun_createdAt_idx" ON public."LoadRun" USING btree ("createdAt");


--
-- Name: Message_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_deletedAt_idx" ON public."Message" USING btree ("deletedAt");


--
-- Name: Message_receiverId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_receiverId_idx" ON public."Message" USING btree ("receiverId");


--
-- Name: Message_senderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Message_senderId_idx" ON public."Message" USING btree ("senderId");


--
-- Name: Notification_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_deletedAt_idx" ON public."Notification" USING btree ("deletedAt");


--
-- Name: Notification_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_read_idx" ON public."Notification" USING btree (read);


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: PasswordReset_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_deletedAt_idx" ON public."PasswordReset" USING btree ("deletedAt");


--
-- Name: PasswordReset_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_token_idx" ON public."PasswordReset" USING btree (token);


--
-- Name: PasswordReset_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordReset_token_key" ON public."PasswordReset" USING btree (token);


--
-- Name: PasswordReset_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordReset_userId_idx" ON public."PasswordReset" USING btree ("userId");


--
-- Name: Payment_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_deletedAt_idx" ON public."Payment" USING btree ("deletedAt");


--
-- Name: Payment_gatewayAuthority_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Payment_gatewayAuthority_key" ON public."Payment" USING btree ("gatewayAuthority");


--
-- Name: Payment_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_status_idx" ON public."Payment" USING btree (status);


--
-- Name: Payment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_userId_idx" ON public."Payment" USING btree ("userId");


--
-- Name: User_deletedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_deletedAt_idx" ON public."User" USING btree ("deletedAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: course_search_gin_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX course_search_gin_idx ON public."CourseSearch" USING gin ("searchVector");


--
-- Name: Certificate Certificate_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Certificate Certificate_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Certificate Certificate_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Certificate"
    ADD CONSTRAINT "Certificate_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Course Course_mentorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Enrollment Enrollment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Enrollment Enrollment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Grade Grade_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Grade"
    ADD CONSTRAINT "Grade_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Lesson Lesson_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 32ryI1gNLfEUeHkhTD1LwY9cAV5TDLOLPzUZuSppAcFRDuCfAlLRxpFnIyIXlYu

